import React from 'react';
import benifits from '../assets/benifits.png';

const Benefits = () => {
  return (
    <div className="bg-white max-w-[1425px] mx-auto">
      <div className="flex flex-col lg:flex-row">
        {/* Left Column - Image Section */}
        <div className="w-full lg:w-1/2 bg-[#377dffbf] rounded-none lg:rounded-r-[35rem] md:rounded-t-[40rem]">
          <div className="relative p-8 lg:p-9 w-full lg:w-[30rem]">
            <h2 className="text-2xl md:text-4xl font-bold text-left text-white">
              Prime Benefits of Azure Face Recognition
            </h2>
            <img 
              src={benifits} 
              alt="Illustration related to UI Design"
              className="hidden lg:block absolute top-[-60px] left-[-18rem] w-[52%] h-[40rem]"
            />
            <img 
              src={benifits} 
              alt="Illustration related to UI Design"
              className="lg:hidden mx-auto mt-8 w-full max-w-md"
            />
          </div>
        </div>

        {/* Right Column - Benefits List */}
        <div className="w-full lg:w-1/2 bg-[#000000b0] rounded-none lg:rounded-[40rem] md:rounded-b-[40rem]">
          <div className="p-5 md:p-8">
            {/* Benefit 1 */}
            <div className="flex flex-col md:flex-row items-center bg-gray-50 rounded-xl mb-5 p-5 shadow-[inset_-6px_6px_13px_4px_rgba(0,0,0,0.1)]">
              <div className="text-4xl md:text-5xl font-bold text-black mb-4 md:mb-0 md:mr-10">1</div>
              <div className="text-center md:text-left">
                <h5 className="text-xl md:text-2xl font-bold text-[#6495ED] mb-2">
                  Experience Cutting-Edge Accuracy
                </h5>
                <p className="text-white text-sm md:text-base">
                  Leverage Azure's advanced Face API to ensure pinpoint accuracy in face detection and verification, providing reliable and precise identity management.
                </p>
              </div>
            </div>

            {/* Benefit 2 */}
            <div className="flex flex-col md:flex-row items-center bg-gray-50 rounded-xl mb-5 p-5 shadow-[inset_-6px_6px_13px_4px_rgba(0,0,0,0.1)]">
              <div className="text-4xl md:text-5xl font-bold text-black mb-4 md:mb-0 md:mr-10">2</div>
              <div className="text-center md:text-left">
                <h5 className="text-xl md:text-2xl font-bold text-[#6495ED] mb-2">
                  Safeguard Your Data
                </h5>
                <p className="text-black text-sm md:text-base">
                  Benefit from Azure's top-notch encryption and access controls, keeping your face data secure and protected against unauthorized access and breaches.
                </p>
              </div>
            </div>

            {/* Benefit 3 */}
            <div className="flex flex-col md:flex-row items-center bg-gray-50 rounded-xl mb-5 p-5 shadow-[inset_-6px_6px_13px_4px_rgba(0,0,0,0.1)]">
              <div className="text-4xl md:text-5xl font-bold text-black mb-4 md:mb-0 md:mr-10">3</div>
              <div className="text-center md:text-left">
                <h5 className="text-xl md:text-2xl font-bold text-[#6495ED] mb-2">
                  Adapt to Your Needs
                </h5>
                <p className="text-black text-sm md:text-base">
                  Enjoy a system that grows with your organization. Whether for small teams or large enterprises, our solution scales effortlessly to handle your face recognition needs.
                </p>
              </div>
            </div>

            {/* Benefit 4 */}
            <div className="flex flex-col md:flex-row items-center bg-gray-50 rounded-xl mb-5 p-5 shadow-[inset_-6px_6px_13px_4px_rgba(0,0,0,0.1)]">
              <div className="text-4xl md:text-5xl font-bold text-black mb-4 md:mb-0 md:mr-10">4</div>
              <div className="text-center md:text-left">
                <h5 className="text-xl md:text-2xl font-bold text-[#6495ED] mb-2">
                  Enhance Your Security
                </h5>
                <p className="text-black text-sm md:text-base">
                  Utilize additional features like anomaly detection and helmet compliance checks to strengthen security and ensure adherence to safety protocols.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Benefits;