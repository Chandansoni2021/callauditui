import { Advantages } from "../assets";
import styles, { layout } from "../style";
import Button from "./Button";
import { useNavigate } from "react-router-dom"; // Import useNavigate

const CardDeal = ({ isLoginOpen, setIsLoginOpen, onLogin }) => {
  const navigate = useNavigate(); // Define useNavigate

  const handleGetStarted = () => {
    setIsLoginOpen(true); // Open the login popup
  };

  return (
    <section className={layout.section}>
      <div className={layout.sectionInfo}>
        <h2 className={`${styles.heading2} text-white`}>
          Discover the Advantages of Our Call Auditing Solution
        </h2>
        <p className={`${styles.paragraph} text-gray-500 max-w-[670px] mt-5`}>
          Our comprehensive call auditing system offers numerous benefits designed to enhance your call center operations and improve customer satisfaction.
        </p>
        <Button styles={`mt-10`} onClick={handleGetStarted} /> {/* Pass onClick prop */}
      </div>

      <div className={layout.sectionImg}>
        <img src={Advantages} alt="billing" className="w-[100%] h-[100%]" />
      </div>
    </section>
  );
};

export default CardDeal;