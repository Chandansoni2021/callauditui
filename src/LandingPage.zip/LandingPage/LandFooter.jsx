import React from "react";
import { FaInstagram, FaYoutube, FaLinkedin } from "react-icons/fa";
import { sg, us, uae, ind } from "../assets";
import { Link } from "react-router-dom";

const LandFooter = () => {
  return (
    <footer className="bg-black text-white text-center p-0 mt-8 font-geologica rounded-t-2xl overflow-hidden relative w-[84rem] ml-[-4rem]">

      {/* Top Section */}
      <div className="flex justify-between items-center p-2.5 mx-auto max-w-7xl">
        <h2 className="text-2xl font-bold">Meridian Solutions</h2>
        <div className="flex gap-6">
          <a
            href="https://www.youtube.com/@onmeridian"
            target="_blank"
            rel="noopener noreferrer"
          >
            <FaYoutube className="text-2xl text-white cursor-pointer transition-transform duration-300 hover:scale-125" />
          </a>
          <a
            href="https://www.instagram.com/onmeridian?igsh=MWw2cjgzZHpobzFuMg=="
            target="_blank"
            rel="noopener noreferrer"
          >
            <FaInstagram className="text-2xl text-white cursor-pointer transition-transform duration-300 hover:scale-125" />
          </a>
          <a
            href="https://www.linkedin.com/company/on-meridian/"
            target="_blank"
            rel="noopener noreferrer"
          >
            <FaLinkedin className="text-2xl text-white cursor-pointer transition-transform duration-300 hover:scale-125" />
          </a>
        </div>
      </div>

      {/* Middle Section - Locations */}
      <div className="flex justify-center flex-wrap gap-12 p-5 mx-auto max-w-7xl">
        <div className="text-center max-w-xs">
          <div className="flex flex-row justify-center items-center gap-4">
            <img src={sg} alt="Singapore Flag" className="w-10 h-6 object-cover mb-1.5" />
            <h3 className="text-lg">Singapore</h3>
          </div>
          <p>68 Circular Road #02-01 Singapore (049422)</p>
        </div>
        <div className="text-center max-w-xs">
          <div className="flex flex-row justify-center items-center gap-4">
            <img src={us} alt="US Flag" className="w-10 h-6 object-cover mb-1.5" />
            <h3 className="text-lg">US</h3>
          </div>
          <p>LLC1207 Delaware Ave #1983 Wilmington, DE 19808</p>
        </div>
        <div className="text-center max-w-xs">
          <div className="flex flex-row justify-center items-center gap-4">
            <img src={ind} alt="India Flag" className="w-10 h-6 object-cover mb-1.5" />
            <h3 className="text-lg">India</h3>
          </div>
          <p>
            Tower 8, Office no. 1103 & 1104, 11th Floor, Spaze IT Tech Park, Gurugram, India
          </p>
        </div>
        <div className="text-center max-w-xs">
          <div className="flex flex-row justify-center items-center gap-4">
            <img src={uae} alt="UAE Flag" className="w-10 h-6 object-cover mb-1.5" />
            <h3 className="text-lg">UAE</h3>
          </div>
          <p>Unique World Business Centre, Al Karama, Dubai, UAE</p>
        </div>
      </div>

      <div className="border-t border-opacity-20 border-white p-2.5 text-sm mx-auto max-w-7xl">
        <p>Meridian Solutions Pvt. Ltd. © 2025. All rights reserved</p>
      </div>
    </footer>
  );
};

export default LandFooter;