import styles from "../style";
import Button from "./Button";

const CTA = ({ isLoginOpen, setIsLoginOpen, onLogin }) => {
  const handleGetStarted = () => {
    setIsLoginOpen(true); // Open the login popup
  };

  return (
    <section className={`${styles.flexCenter} ${styles.marginY} ${styles.padding} sm:flex-row flex-col bg-black-gradient-2 rounded-[20px] box-shadow`}>
      <div className="flex-1 flex flex-col">
        <h2 className={styles.heading2}>Experience Our Call Auditing Service Today!</h2>
        <p className={`${styles.paragraph} max-w-[470px] mt-5 text-gray-500`}>
          Enhance your call center's quality and boost customer satisfaction with our comprehensive call auditing solutions.
        </p>
      </div>

      <div className={`${styles.flexCenter} sm:ml-10 ml-0 sm:mt-0 mt-10`}>
        <Button onClick={handleGetStarted} /> {/* Pass onClick prop */}
      </div>
    </section>
  );
};

export default CTA;