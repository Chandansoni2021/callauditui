import { features } from "../constants";
import styles, { layout } from "../style";
import Button from "./Button";
import { useNavigate } from "react-router-dom"; // Import useNavigate

const FeatureCard = ({ icon, title, content, index }) => (
  <div className={`flex flex-row p-6 rounded-[20px] ${index !== features.length - 1 ? "mb-6" : "mb-0"} feature-card`}>
    <div className={`w-[64px] h-[64px] rounded-full ${styles.flexCenter} bg-dimBlue`}>
      <img src={icon} alt="star" className="w-[50%] h-[50%] object-contain" />
    </div>
    <div className="flex-1 flex flex-col ml-3">
      <h4 className="font-poppins font-semibold text-white text-[18px] leading-[23.4px] mb-1">
        {title}
      </h4>
      <p className="font-poppins font-normal text-dimWhite text-[16px] leading-[24px]">
        {content}
      </p>
    </div>
  </div>
);

const Business = ({ isLoginOpen, setIsLoginOpen, onLogin }) => {
  const navigate = useNavigate(); // Define useNavigate

  const handleGetStarted = () => {
    setIsLoginOpen(true); // Open the login popup
  };

  return (
    <section id="features" className={layout.section}>
      <div className={layout.sectionInfo}>
        <h2 className={`${styles.heading2} text-white`}>
          Focus on Your Business, <br className="sm:block hidden" /> We'll Ensure Call Quality.
        </h2>
        <p className={`${styles.paragraph} max-w-[470px] mt-5 text-white`}>
          Our comprehensive call auditing solution evaluates agent performance, ensures compliance, and enhances customer satisfaction. Let us help you optimize your call center operations for peak efficiency.
        </p>

        <Button styles={`mt-10`} onClick={handleGetStarted} /> {/* Pass onClick prop */}
      </div>

      <div className={`${layout.sectionImg} flex-col text-white`}>
        {features.map((feature, index) => (
          <FeatureCard key={feature.id} {...feature} index={index} />
        ))}
      </div>
    </section>
  );
};

export default Business;