import styles from "../style";
import { whitelogo, heroig } from "../assets";
import GetStarted from "./GetStarted";
import { useNavigate } from "react-router-dom";

const Hero = ({ isLoginOpen, setIsLoginOpen, onLogin }) => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    setIsLoginOpen(true); // Open the login popup
  };

  return (
    <section id="home" className={`flex md:flex-row flex-col ${styles.paddingY}`}>
      <div className={`flex-1 ${styles.flexStart} flex-col mt-20 xl:px-0 sm:px-16 px-6`}>
        <div className="flex flex-row items-center mb-[1rem]">
          <img src={whitelogo} alt="discount" className="w-[10rem] h-[3rem]" />
        </div>

        <div className="flex flex-col w-full">
          <h1 className="font-poppins font-semibold ss:text-[72px] text-[52px] text-white ss:leading-[100.8px] leading-[75px]">
            Elevate Your <br className="sm:block hidden" />{" "}
            <span className="text-gradient">Call Quality</span>{" "}
          </h1>

          <h1 className="font-poppins font-semibold ss:text-[68px] text-[52px] text-white ss:leading-[100.8px] leading-[75px] w-full">
            Through Effective Auditing
          </h1>

          <p className={`${styles.paragraph} max-w-[470px] mt-5 text-white`}>
            Implementing systematic call audits helps in evaluating agent performance, ensuring compliance, and enhancing customer satisfaction. Discover strategies to optimize your call center operations.
          </p>

          <div className="mt-8">
            <GetStarted onClick={handleGetStarted} />
          </div>
        </div>
      </div>

      <div className={`flex-1 flex ${styles.flexCenter} md:my-0 my-10 relative`}>
        <img src={heroig} alt="billing" className="w-[80%] h-[80%] relative" />
        <div className="absolute z-[0] w-[40%] h-[35%] top-0 pink__gradient" />
        <div className="absolute z-[1] w-[80%] h-[80%] rounded-full white__gradient bottom-40" />
        <div className="absolute z-[0] w-[50%] h-[50%] right-20 bottom-20 blue__gradient" />
      </div>
    </section>
  );
};

export default Hero;