import Navbar from "./LandNavbar";
import Hero from "./Hero";
import Business from "./Business";
import Billing from "./Billing";
import CardDeal from "./CardDeal";
import CTA from "./CTA";
import Footer from "./LandFooter";

export {
  Navbar,
  Hero,
  Business,
  Billing,
  CardDeal,
  CTA,
  Footer,
};
